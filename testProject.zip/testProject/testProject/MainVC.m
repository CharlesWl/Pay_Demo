//
//  MainVC.m
//  testProject
//
//  Created by 王涛 on 16/8/16.
//  Copyright © 2016年 王涛. All rights reserved.
//

#import "MainVC.h"
#import "UIView+Frame.h"

@interface MainVC () <QAResultVCDelegate>
@property (strong, nonatomic) IBOutlet UIView *headView;
@property (strong,nonatomic) childrenVC* resultVC;
@end

@implementation MainVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.edgesForExtendedLayout = UIRectEdgeNone;
    [self initUI];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - init

- (void)initUI {
    
    self.headView.frame = CGRectMake(0, 0, kScreenWidth, 200);
    [self.view addSubview:self.headView];
    
    self.resultVC.delegate = self;
    self.resultVC.view.autoresizingMask = UIViewAutoresizingNone;
    self.resultVC.view.frame = CGRectMake(0,self.headView.frame.origin.y+ self.headView.frame.size.height,kScreenWidth, kScreenHeight-64);
    [self.view addSubview:self.resultVC.view];

}

#pragma mark - QAResultVCDelegate

-(void)didScrollTableView:(UIScrollView *)tableView atDirection:(ScrollViewDirection)direction offsetY:(CGFloat)offsetY{
    if(direction == ScrollViewDirection_Up){
        if (self.headView.y > -self.headView.height && offsetY > 0) {
            self.headView.y -= offsetY;
            if (self.headView.y < -self.headView.height) {
                self.headView.y = -self.headView.height;
            }
            [tableView setContentOffset:CGPointMake(0, 0)];
            self.resultVC.view.y = self.headView.y + self.headView.height;
        }
    }else if(direction == ScrollViewDirection_Down){
        if (self.headView.y < 0  && offsetY < 0) {
            self.headView.y += -offsetY;
            if (self.headView.y > 0) {
                self.headView.y = 0;
            }
            [tableView setContentOffset:CGPointMake(0, 0)];
            self.resultVC.view.y = self.headView.y + self.headView.height;
        }
    }
}

- (void)didClickOnMenuViewIndex:(NSInteger)index {
    [UIView animateWithDuration:0.2 animations:^{
        self.headView.y = -self.headView.height;
        self.resultVC.view.y = self.headView.y + self.headView.height;
    }];
}

- (childrenVC *)resultVC {
    if (!_resultVC) {
        _resultVC = [[childrenVC alloc] initWithNibName:@"childrenVC" bundle:nil];
    }
    return _resultVC;
}

@end
