//
//  UIScrollView+Direction.h
//  QQingCommon
//
//  Created by 郭晓倩 on 16/4/20.
//  Copyright © 2016年 QQingiOSTeam. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSUInteger, ScrollViewDirection) {
    ScrollViewDirection_Up,
    ScrollViewDirection_Down,
    ScrollViewDirection_None,//无方向
};

@interface UIScrollView (Direction)

@property (assign,nonatomic) CGPoint lastOffset;
@property (assign,nonatomic) ScrollViewDirection lastDirection;

-(ScrollViewDirection)currentDirection;

@end
