//
//  UIScrollView+Direction.m
//  QQingCommon
//
//  Created by 郭晓倩 on 16/4/20.
//  Copyright © 2016年 QQingiOSTeam. All rights reserved.
//

#import "UIScrollView+Direction.h"
#import <objc/runtime.h>

@implementation UIScrollView (Direction)

#pragma mark - 运行时增加一个属性

static char UIScrollViewLastOffsetKey;
static char UIScrollViewLastDirectionKey;

- (void)setLastOffset:(CGPoint)lastOffset {
    NSDictionary* offsetDic = @{@"x":@(lastOffset.x),@"y":@(lastOffset.y)};
    [self willChangeValueForKey:@"UIScrollViewLastOffsetKey"];
    objc_setAssociatedObject(self, &UIScrollViewLastOffsetKey,
                             offsetDic,
                             OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    [self didChangeValueForKey:@"UIScrollViewLastOffsetKey"];
}

- (CGPoint)lastOffset {
    NSDictionary* offsetDic = (NSDictionary*)(objc_getAssociatedObject(self, &UIScrollViewLastOffsetKey));
    if (![offsetDic isKindOfClass:[NSDictionary class]] ) {
        return CGPointMake(0, 0);
    }else{
        return CGPointMake([[offsetDic objectForKey:@"x"] floatValue], [[offsetDic objectForKey:@"y"] floatValue]);
    }
}

- (void)setLastDirection:(ScrollViewDirection)lastDirection {
    [self willChangeValueForKey:@"UIScrollViewLastDirectionKey"];
    objc_setAssociatedObject(self, &UIScrollViewLastDirectionKey,
                             @(lastDirection),
                             OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    [self didChangeValueForKey:@"UIScrollViewLastDirectionKey"];
}

- (ScrollViewDirection)lastDirection {
    NSNumber* lastDirection = (NSNumber*)(objc_getAssociatedObject(self, &UIScrollViewLastDirectionKey));
    if (lastDirection == nil) {
        return ScrollViewDirection_None;
    }else{
        return lastDirection.integerValue;
    }
}

-(ScrollViewDirection)currentDirection{
    CGPoint lastOffset = self.lastOffset;
    self.lastOffset = self.contentOffset;
    ScrollViewDirection direction = ScrollViewDirection_None;
    if (self.contentOffset.y > lastOffset.y) {
        direction = ScrollViewDirection_Up;
    }else if(self.contentOffset.y < lastOffset.y){
        direction = ScrollViewDirection_Down;
    }
    self.lastDirection = direction;
    return direction;
}


@end
