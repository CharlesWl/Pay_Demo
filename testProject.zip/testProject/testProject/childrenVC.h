//
//  childrenVC.h
//  testProject
//
//  Created by 王涛 on 16/8/16.
//  Copyright © 2016年 王涛. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIScrollView+Direction.h"

#define kScreenWidth ([UIScreen mainScreen].bounds.size.width)
#define kScreenHeight ([UIScreen mainScreen].bounds.size.height)

@protocol QAResultVCDelegate <NSObject>

@required
-(void)didScrollTableView:(UIScrollView*)tableView atDirection:(ScrollViewDirection)direction offsetY:(CGFloat)offsetY;
-(void)didClickOnMenuViewIndex:(NSInteger)index;
@end

@interface childrenVC : UIViewController
@property (weak,nonatomic) id<QAResultVCDelegate> delegate;
@end
