//
//  ViewController.m
//  testProject
//
//  Created by 王涛 on 16/8/16.
//  Copyright © 2016年 王涛. All rights reserved.
//

#import "ViewController.h"
#import "MainVC.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.navigationController pushViewController:[[MainVC alloc] initWithNibName:@"MainVC" bundle:nil] animated:NO];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
