//
//  childrenVC.m
//  testProject
//
//  Created by 王涛 on 16/8/16.
//  Copyright © 2016年 王涛. All rights reserved.
//

#import "childrenVC.h"
#import "UIView+Frame.h"

@interface childrenVC () <UITableViewDataSource,UITableViewDelegate,UIScrollViewDelegate>
@property (weak, nonatomic) IBOutlet UIView *menuBarView;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *contentViewWidthCons;

@property (weak, nonatomic) IBOutlet UIButton *fantaMenuButton;
@property (weak, nonatomic) IBOutlet UIButton *newsMenuButton;
@property (strong,nonatomic) NSArray* menuButtonArray;

@property (strong,nonatomic) UIView* bottomMenuLine;
@property (assign,nonatomic) CGFloat bottomMenuLineScrollWidth;

@property (strong,nonatomic) UITableView* tableViewForFanta;
@property (strong,nonatomic) UITableView* tableViewForNews;
@end

@implementation childrenVC

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initUI];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - init 

- (void)initUI {
    
    //菜单选项
    self.menuButtonArray = @[self.fantaMenuButton,self.newsMenuButton];
    CGFloat menuItemWidth = kScreenWidth / 2;
    self.bottomMenuLineScrollWidth = kScreenWidth/2;
    self.bottomMenuLine = [[UIView alloc] initWithFrame:CGRectMake(0, self.menuBarView.height-2, menuItemWidth, 2)];
    self.bottomMenuLine.backgroundColor = [UIColor greenColor];
    
    CGFloat scrollContentHeight = kScreenHeight - 64 - self.menuBarView.frame.size.height;
    self.tableViewForFanta = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, kScreenWidth, scrollContentHeight) style:UITableViewStylePlain];
    self.tableViewForNews = [[UITableView alloc] initWithFrame:CGRectMake(kScreenWidth, 0, kScreenWidth, scrollContentHeight) style:UITableViewStylePlain];
    NSArray* tableViews = @[self.tableViewForFanta,self.tableViewForNews];
    for (int i=0; i < tableViews.count; ++i) {
        UITableView* tableView = [tableViews objectAtIndex:i];
        
        tableView.dataSource = self;
        tableView.delegate = self;
        tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        
        [self.scrollView addSubview:tableView];
    }
    self.contentViewWidthCons.constant = kScreenWidth*2;
    
}

#pragma mark - UITableViewDataSource

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 1;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    if (tableView == self.tableViewForNews) {
        return 10;
    }else{
        return 50;
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    cell.textLabel.text = [NSString stringWithFormat:@"测试：%@",indexPath];
    if (tableView == self.tableViewForNews) {
        cell.backgroundColor = [UIColor redColor];
    }else{
        cell.backgroundColor = [UIColor blueColor];
    }
    return cell;
}

#pragma mark - UITableViewDelegate

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 1;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 40;
}

#pragma mark - UIScrollViewDelegate

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView {
    if (scrollView == self.scrollView) {
        if (scrollView.contentOffset.x == 0) {
            [self selectSegmentIndex:0];
        }else if (scrollView.contentOffset.x == kScreenWidth) {
            [self selectSegmentIndex:1];
        }
    }
}

- (void)scrollViewDidScroll:(UIScrollView *)scrollView{
    CGFloat offsetY = scrollView.contentOffset.y;
    ScrollViewDirection direction = [scrollView currentDirection];
    if(scrollView == self.scrollView){
        //菜单底部横线跟随滑动
        CGFloat scrollOffsetRatio = scrollView.contentOffset.x / (2*kScreenWidth);
        self.bottomMenuLine.x = self.bottomMenuLineScrollWidth * scrollOffsetRatio;
    }else{
        
        if (self.delegate) {
            [self.delegate didScrollTableView:scrollView atDirection:direction offsetY:offsetY];
        }
    }
}

#pragma mark - Action

- (IBAction)didClickOnSegment:(UIButton *)sender {
    
    [self selectSegmentIndex:[self.menuButtonArray indexOfObject:sender]];
    if (self.delegate) {
        [self.delegate didClickOnMenuViewIndex:[self.menuButtonArray indexOfObject:sender]];
    }
    
}


-(void)selectSegmentIndex:(NSInteger)index{
    for (int i=0; i < self.menuButtonArray.count; ++i) {
        UIButton* button = [self.menuButtonArray objectAtIndex:i];
        if (i == index) {
            button.selected = YES;
            self.bottomMenuLine.x = self.bottomMenuLineScrollWidth * index;
        }else{
            button.selected = NO;
        }
    }
    
    [self.scrollView setContentOffset:CGPointMake(index * kScreenWidth, 0) animated:YES];
}


@end
