//
//  ViewController.m
//  animationTest
//
//  Created by 王涛 on 16/8/15.
//  Copyright © 2016年 王涛. All rights reserved.
//

#import "ViewController.h"
#import "CoreAnimationTestVC.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    CoreAnimationTestVC *vc = [[CoreAnimationTestVC alloc] init];
    [self addChildViewController:vc];
    vc.view.frame = self.view.frame;
    [self.view addSubview:vc.view];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
