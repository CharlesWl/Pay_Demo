//
//  CoreAnimationTestVC.m
//  QQing
//
//  Created by 王涛 on 16/8/11.
//
//

#import "CoreAnimationTestVC.h"
#import "BezierPathView.h"

#define kScreenWidth ([UIScreen mainScreen].bounds.size.width)

@interface CoreAnimationTestVC () <UIScrollViewDelegate>

@property (nonatomic, strong) CAShapeLayer *shapeLayer;
@property (nonatomic, strong) UIBezierPath *bezierPath;

// 粒子
@property (nonatomic, strong) CAEmitterLayer *emitterLayer;
@property (nonatomic, strong) UILabel *angleLabel;

@property (weak, nonatomic) IBOutlet BezierPathView *bezierPathView;

@end

@implementation CoreAnimationTestVC

- (void)viewDidLoad {
    [super viewDidLoad];
    [self shapeLayerTest];
    //[self addViewTest];
    [self addEmitter];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

// CAShapeLayer
- (void)shapeLayerTest {
    //创建出CAShapeLayer
    self.shapeLayer = [CAShapeLayer layer];
    self.shapeLayer.frame = CGRectMake(0, 0, kScreenWidth, self.bezierPathView.frame.size.height);//设置shapeLayer的尺寸和位置
    self.shapeLayer.anchorPoint = CGPointMake(0.5, 0.5);
    self.shapeLayer.fillColor = [UIColor clearColor].CGColor;//填充颜色为ClearColor
    
    //设置线条的宽度和颜色
    self.shapeLayer.lineWidth = 1.0f;
    self.shapeLayer.strokeColor = [UIColor redColor].CGColor;
    
    //创建出圆形贝塞尔曲线
    self.bezierPath = [UIBezierPath bezierPath];
    [_bezierPath moveToPoint:CGPointMake(1, 1)];
    [_bezierPath addLineToPoint:CGPointMake(1,self.bezierPathView.frame.size.height)];
    [_bezierPath addQuadCurveToPoint:CGPointMake(kScreenWidth-1,self.bezierPathView.frame.size.height) controlPoint:CGPointMake(kScreenWidth/2,self.bezierPathView.frame.size.height + 20)];
    [_bezierPath addLineToPoint:CGPointMake(kScreenWidth-1,1)];
    [_bezierPath addLineToPoint:CGPointMake(1, 1)];
    [_bezierPath closePath];
    //让贝塞尔曲线与CAShapeLayer产生联系
    self.shapeLayer.path = self.bezierPath.CGPath;
    //设置stroke起始点
    self.shapeLayer.strokeStart = 0;
    self.shapeLayer.strokeEnd = 1;
    //添加并显示
    [self.bezierPathView.layer addSublayer:self.shapeLayer];
    
    // 添加动画
    [self addAnimation];
}

- (void)addViewTest {
    
    int oneLineCount = 6; // 每一行的个数
    float gapH = 12;      // 水平间距
    float gapV = 12;      // 垂直间距
    float viewW = (kScreenWidth - (oneLineCount+1)*gapH)/oneLineCount; // 视图宽度
    float viewH = 30;     // 视图高度
    float currentX = 12;
    float currentY = 12;
    for (int i = 0; i < 13; ++ i) {
        currentX = gapH + i%oneLineCount * (viewW+gapH);
        currentY = gapV + i/oneLineCount * (viewH+gapV);
        UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(currentX, currentY, viewW, viewH)];
        label.backgroundColor = [UIColor blueColor];
        label.textColor = [UIColor whiteColor];
        label.text = [NSString stringWithFormat:@"W%d",i];
        NSLog(@"W%d currentX:%f currentY:%f",i,currentX,currentY);
        [self.view addSubview:label];
    }

}

- (void)addAnimation {
    
    CABasicAnimation *animation = [CABasicAnimation animationWithKeyPath:@"strokeEnd"];
    animation.fromValue = @(0.0);
    animation.toValue = @(1.0);
    animation.duration = 2.0;
    
    // 设置layer的animation
    [self.shapeLayer addAnimation:animation forKey:nil];
    
    animation.fillMode = kCAFillModeForwards;
    animation.removedOnCompletion = YES;
}

// 粒子效果
- (void)addEmitter {
    
    CAEmitterLayer *emitterLayer = [CAEmitterLayer layer];
    emitterLayer.emitterPosition = self.bezierPathView.center;
    _emitterLayer = emitterLayer;
    // 显示边框
    emitterLayer.borderWidth = 1.f;
    // 给定尺寸
    //emitterLayer.frame = CGRectMake(100, 100, 100, 100);
    // 发射模式
    emitterLayer.emitterMode =kCAEmitterLayerSurface;
    // 发射形状
    emitterLayer.emitterShape =kCAEmitterLayerLine;
    [self.bezierPathView.layer addSublayer:emitterLayer];
    
    CAEmitterCell *funnyEmitterCell = [CAEmitterCell emitterCell];
    funnyEmitterCell.contents = (id)[UIImage imageNamed:@"icon_diamond"].CGImage;
    //funnyEmitterCell.color = [UIColor teOrangeColor].CGColor;
    funnyEmitterCell.birthRate = 5.0;
    funnyEmitterCell.velocityRange = 200.0;
    funnyEmitterCell.lifetime = 5.0;
    funnyEmitterCell.scale = 0.3;
    funnyEmitterCell.name = @"funny";
    funnyEmitterCell.emissionRange = M_PI/2;
    //funnyEmitterCell.emissionLongitude = M_PI/2;
    emitterLayer.emitterCells = @[funnyEmitterCell];
    
}

#pragma mark - UIScrollViewDelegate

- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    
    if (scrollView.contentOffset.y < 0) {
        self.bezierPath = [UIBezierPath bezierPath];
        [_bezierPath moveToPoint:CGPointMake(1, 1)];
        [_bezierPath addLineToPoint:CGPointMake(1,self.bezierPathView.frame.size.height)];
        [_bezierPath addQuadCurveToPoint:CGPointMake(kScreenWidth,self.bezierPathView.frame.size.height) controlPoint:CGPointMake(kScreenWidth/2,self.bezierPathView.frame.size.height - scrollView.contentOffset.y)];
        [_bezierPath addLineToPoint:CGPointMake(kScreenWidth,1)];
        [_bezierPath addLineToPoint:CGPointMake(1, 1)];
        [_bezierPath closePath];
        //让贝塞尔曲线与CAShapeLayer产生联系
        self.shapeLayer.path = self.bezierPath.CGPath;    }
    
}
@end
