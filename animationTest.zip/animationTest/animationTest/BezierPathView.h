//
//  BezierPathView.h
//  QQing
//
//  Created by 王涛 on 16/8/11.
//
//

#import <UIKit/UIKit.h>

@interface BezierPathView : UIView
@property (nonatomic, assign) CGPoint controlPoint;
@end
