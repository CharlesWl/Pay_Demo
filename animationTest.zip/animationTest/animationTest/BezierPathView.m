//
//  BezierPathView.m
//  QQing
//
//  Created by 王涛 on 16/8/11.
//
//

#import "BezierPathView.h"

#define   kDegreesToRadians(degrees)  ((M_PI * degrees)/ 180)

@interface BezierPathView ()
@property (nonatomic, strong) CAShapeLayer *shapeLayer;
@property (nonatomic, strong) UIBezierPath *bezierPath;
@end

@implementation BezierPathView

// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
    [self drawTriangPath];
    //[self drawOvalPath];
    //[self drawOneCorner];
    //[self drawARCPath];
    //[self drawSecondBezierPath];
    //[self shapeLayerTest];
}

- (void)drawTriangPath {
    
    // 画图
    UIBezierPath *path = [UIBezierPath bezierPath];
    [path moveToPoint:CGPointMake(12, self.frame.size.height - 12)];
    [path addLineToPoint:CGPointMake(self.frame.size.width - 12, self.frame.size.height - 12)];
    [path addLineToPoint:CGPointMake(self.frame.size.width/2, 12)];
    [path closePath];
    
    // 填充颜色
    UIColor *fillColor = [UIColor redColor];
    [fillColor set];
    [path fill];
    
    // 画笔颜色
    UIColor *strokeColor = [UIColor yellowColor];
    [strokeColor set];
    [path stroke];
    
    //
    path.lineWidth = 1.5;
//    path.lineCapStyle = kCGLineCapRound;    // 设置线条拐角帽的样式
//    path.lineJoinStyle = kCGLineJoinMiter;  // 设置两条线连结点的样式
}


// 画椭圆
- (void)drawOvalPath {
    // 传的是不是正方形，因此就可以绘制出椭圆圆了
    UIBezierPath *path = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(20, 20, self.frame.size.width - 40, self.frame.size.height - 40)];
    
    // 设置填充颜色
    UIColor *fillColor = [UIColor greenColor];
    [fillColor set];
    [path fill];
    
    // 设置画笔颜色
    UIColor *strokeColor = [UIColor redColor];
    [strokeColor set];
    [path stroke];
    
}

// 设置圆角的矩形
- (void)drawOneCorner {
    
    UIBezierPath *path = [UIBezierPath bezierPathWithRoundedRect:CGRectMake(0, 0, self.frame.size.width, self.frame.size.height)
                                               byRoundingCorners:UIRectCornerTopRight | UIRectCornerTopLeft
                                                     cornerRadii:CGSizeMake(20, 20)];
    path.lineWidth = 5;
    // 设置画笔颜色
    UIColor *strokeColor = [UIColor yellowColor];
    [strokeColor set];
    [path stroke];
    
    path.lineCapStyle = kCGLineCapButt;    // 设置线条拐角帽的样式
    path.lineJoinStyle = kCGLineJoinBevel;  // 设置两条线连结点的样式
}

// 画弧
- (void)drawARCPath {
    
    CGPoint center = CGPointMake(self.frame.size.width / 2, self.frame.size.height / 2);
    UIBezierPath *path = [UIBezierPath bezierPathWithArcCenter:center
                                                        radius:self.frame.size.height / 2
                                                    startAngle:kDegreesToRadians(270)
                                                      endAngle:kDegreesToRadians(90)
                                                     clockwise:YES];
    
    path.lineCapStyle = kCGLineCapRound;
    path.lineJoinStyle = kCGLineJoinRound;
    path.lineWidth = 5.0;
    
    UIColor *strokeColor = [UIColor redColor];
    [strokeColor set];
    [path stroke];
}

// 二次曲线
- (void)drawSecondBezierPath {
    
    UIBezierPath *path = [UIBezierPath bezierPath];
    // 首先设置一个起始点
    [path moveToPoint:CGPointMake(20, self.frame.size.height - 20)];
    // 添加二次曲线
    [path addQuadCurveToPoint:CGPointMake(self.frame.size.width-20, self.frame.size.height - 20) controlPoint:CGPointMake(40,50)];
    
    path.lineCapStyle = kCGLineCapRound;
    path.lineJoinStyle = kCGLineJoinRound;
    
    UIColor *strokeColor = [UIColor blueColor];
    [strokeColor set];
    [path stroke];
    
}

// CAShapeLayer
- (void)shapeLayerTest {
    
    //创建出CAShapeLayer
    self.shapeLayer = [CAShapeLayer layer];
    self.shapeLayer.frame = CGRectMake(0, 0, self.frame.size.width, self.frame.size.height);
    self.shapeLayer.position = self.center;
    self.shapeLayer.anchorPoint = CGPointMake(0.5, 0.5);
    self.shapeLayer.fillColor = [UIColor clearColor].CGColor;//填充颜色为ClearColor
    
    //设置线条的宽度和颜色
    self.shapeLayer.lineWidth = 1.0f;
    self.shapeLayer.strokeColor = [UIColor redColor].CGColor;
    
//    //创建出圆形贝塞尔曲线
//    UIBezierPath *path = [UIBezierPath bezierPathWithOvalInRect:CGRectMake(0, 0, 240, 240)];
//    
//    //让贝塞尔曲线与CAShapeLayer产生联系
//    self.shapeLayer.path = path.CGPath;
//    //设置stroke起始点
//    self.shapeLayer.strokeStart = 0;
//    self.shapeLayer.strokeEnd = 0.75;
    //添加并显示
    [self.layer addSublayer:self.shapeLayer];
    self.shapeLayer.path = self.bezierPath.CGPath;
}


- (void)setControlPoint:(CGPoint)controlPoint {
    
    _controlPoint = controlPoint;
    [_bezierPath addQuadCurveToPoint:CGPointMake(self.frame.size.width,0) controlPoint:controlPoint];
    
}

- (UIBezierPath *)bezierPath {
    if (!_bezierPath) {
        _bezierPath = [UIBezierPath bezierPath];
        [_bezierPath moveToPoint:CGPointMake(0, 0)];
        [_bezierPath addLineToPoint:CGPointMake(0,self.frame.size.height)];
        [_bezierPath addLineToPoint:CGPointMake(self.frame.size.width,self.frame.size.height)];
        [_bezierPath addLineToPoint:CGPointMake(self.frame.size.width,0)];
        [_bezierPath addQuadCurveToPoint:CGPointMake(self.frame.size.width,0) controlPoint:CGPointMake(self.frame.size.width/2,-20)];
        [_bezierPath closePath];
    }
    return _bezierPath;
}

@end
