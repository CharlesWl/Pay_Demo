//
//  MD5DataSigner.h
//  SafepayService
//
//  Created by wenbi on 11-4-11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "DataSigner.h"

@interface MD5DataSigner : NSObject <DataSigner> {
}

@end
